# epitech-emacs
Official Emacs configuration for Epitech students.

## Installation

- For local installation, run `./INSTALL.sh local`.
- For system-wide installation, run `sudo ./INSTALL.sh system`